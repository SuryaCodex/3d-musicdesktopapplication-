import pytest
from app.music_engine import MusicEngine

def qt_app():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])

def test_music_engine_initialization():
    qt_app()
    engine = MusicEngine()
    assert engine.playlist == []
    assert engine.current_index == 0
    assert engine.shuffle_enabled is False
    assert engine.repeat_mode == "playlist"
