from PySide6.QtCore import QUrl, QObject, Signal
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
import random

class MusicEngine(QObject):
    stateChanged = Signal(str)
    songChanged = Signal(dict)
    positionChanged = Signal(int)

    def __init__(self):
        super().__init__()
        self.player = QMediaPlayer()
        self.audio_output = QAudioOutput()
        self.player.setAudioOutput(self.audio_output)
        
        self.playlist = []
        self.current_index = 0
        self.shuffle_enabled = False
        self.repeat_mode = "playlist" # 'off', 'song', 'playlist'
        
        self.audio_output.setVolume(0.8)
        self.player.playbackStateChanged.connect(self._handle_state_change)
        self.player.positionChanged.connect(self.positionChanged.emit)
        self.player.mediaStatusChanged.connect(self._handle_media_status)

    def load_playlist(self, songs):
        self.playlist = songs
        self.current_index = 0

    def play(self, index=None):
        if index is not None:
            self.current_index = index
        if not self.playlist:
            return
        
        song = self.playlist[self.current_index]
        self.player.setSource(QUrl.fromLocalFile(song["file_path"]))
        self.player.play()
        self.songChanged.emit(song)

    def pause_resume(self):
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
        elif self.player.playbackState() == QMediaPlayer.PlaybackState.PausedState:
            self.player.play()
        elif self.playlist:
            self.play(self.current_index)

    def stop(self):
        self.player.stop()
        self.stateChanged.emit("Stopped")

    def next_song(self):
        if not self.playlist:
            return
        if self.shuffle_enabled:
            self.current_index = random.randint(0, len(self.playlist) - 1)
        else:
            self.current_index = (self.current_index + 1) % len(self.playlist)
        self.play(self.current_index)

    def previous_song(self):
        if not self.playlist:
            return
        self.current_index = (self.current_index - 1) % len(self.playlist)
        self.play(self.current_index)

    def set_volume(self, volume):
        self.audio_output.setVolume(max(0.0, min(1.0, volume)))

    def _handle_state_change(self, state):
        state_map = {
            QMediaPlayer.PlaybackState.PlayingState: "Playing",
            QMediaPlayer.PlaybackState.PausedState: "Paused",
            QMediaPlayer.PlaybackState.StoppedState: "Stopped"
        }
        self.stateChanged.emit(state_map.get(state, "Unknown"))

    def _handle_media_status(self, status):
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            if self.repeat_mode == "song":
                self.play(self.current_index)
            else:
                self.next_song()
