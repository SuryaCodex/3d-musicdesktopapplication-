import os
import mutagen
from mutagen.id3 import ID3
from mutagen.flac import FLAC
from mutagen.mp4 import MP4
from app.database import get_connection

ARTWORK_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "posters")

class ArtworkManager:
    @staticmethod
    def extract_and_save_artwork(file_path):
        os.makedirs(ARTWORK_DIR, exist_ok=True)
        base_name = os.path.splitext(os.path.basename(file_path))[0]
        output_art_path = os.path.join(ARTWORK_DIR, f"{base_name}.jpg")

        if os.path.exists(output_art_path):
            return output_art_path

        try:
            audio = mutagen.File(file_path)
            artwork_data = None

            if isinstance(audio, ID3) or (hasattr(audio, "tags") and audio.tags):
                tags = audio.tags if not isinstance(audio, ID3) else audio
                for tag_key in tags.keys():
                    if tag_key.startswith("APIC:"):
                        artwork_data = tags[tag_key].data
                        break
            elif isinstance(audio, FLAC):
                if audio.pictures:
                    artwork_data = audio.pictures[0].data
            elif isinstance(audio, MP4):
                if "covr" in audio:
                    artwork_data = audio[0]

            if artwork_data:
                with open(output_art_path, "wb") as img_file:
                    img_file.write(artwork_data)
                return output_art_path
        except Exception as e:
            print(f"Error extracting artwork for {file_path}: {e}")

        return os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "icons", "default_poster.jpg")
