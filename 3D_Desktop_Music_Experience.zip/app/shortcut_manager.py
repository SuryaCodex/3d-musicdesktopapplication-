import ctypes
import threading
from PySide6.QtCore import QObject, Signal

MOD_ALT = 0x0001
MOD_CONTROL = 0x0002

WM_HOTKEY = 0x0312

class ShortcutManager(QObject):
    triggered = Signal(str)

    def __init__(self):
        super().__init__()
        self.hotkeys = {
            1: "activate",
            2: "play_pause",
            3: "next",
            4: "previous",
            5: "mini_player",
            6: "hide",
            7: "exit"
        }
        self._running = True
        self.thread = threading.Thread(target=self._message_loop, daemon=True)

    def start(self):
        self.thread.start()

    def _message_loop(self):
        user32 = ctypes.windll.user32
        
        user32.RegisterHotKey(None, 1, MOD_CONTROL | MOD_ALT, ord('R'))
        user32.RegisterHotKey(None, 2, MOD_CONTROL | MOD_ALT, ord('P'))
        user32.RegisterHotKey(None, 3, MOD_CONTROL | MOD_ALT, 0x27)
        user32.RegisterHotKey(None, 4, MOD_CONTROL | MOD_ALT, 0x25)
        user32.RegisterHotKey(None, 5, MOD_CONTROL | MOD_ALT, ord('M'))
        user32.RegisterHotKey(None, 6, MOD_CONTROL | MOD_ALT, ord('H'))
        user32.RegisterHotKey(None, 7, MOD_CONTROL | MOD_ALT, ord('Q'))

        try:
            msg = ctypes.wintypes.MSG()
            while self._running:
                if user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
                    if msg.message == WM_HOTKEY:
                        action = self.hotkeys.get(msg.wParam)
                        if action:
                            self.triggered.emit(action)
                    user32.TranslateMessage(ctypes.byref(msg))
                    user32.DispatchMessageW(ctypes.byref(msg))
        finally:
            for hotkey_id in self.hotkeys.keys():
                user32.UnregisterHotKey(None, hotkey_id)

    def stop(self):
        self._running = False
