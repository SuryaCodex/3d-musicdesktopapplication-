from PySide6.QtCore import QObject, Slot, Signal

class Bridge(QObject):
    jsCommandReceived = Signal(str, dict)

    def __init__(self, music_engine):
        super().__init__()
        self.music_engine = music_engine

    @Slot(str)
    def handleCommand(self, cmd):
        if cmd == "play":
            self.music_engine.play()
        elif cmd == "pause":
            self.music_engine.pause_resume()
        elif cmd == "next":
            self.music_engine.next_song()
        elif cmd == "previous":
            self.music_engine.previous_song()
        elif cmd == "stop":
            self.music_engine.stop()
