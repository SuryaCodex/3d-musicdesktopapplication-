from app.database import get_connection

class PlaylistManager:
    @staticmethod
    def get_default_playlist_songs():
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.id, s.file_path, s.title, s.artist, s.album, s.duration, s.artwork_path
            FROM songs s
            JOIN playlist_items pi ON s.id = pi.song_id
            JOIN playlists p ON pi.playlist_id = p.id
            WHERE p.is_default = 1
            ORDER BY pi.position ASC
        """)
        songs = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return songs

    @staticmethod
    def add_song_to_default_playlist(file_path, title, artist, album, duration, artwork_path):
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM playlists WHERE is_default = 1")
        pl = cursor.fetchone()
        if not pl:
            cursor.execute("INSERT INTO playlists (name, is_default) VALUES ('Default Playlist', 1)")
            playlist_id = cursor.lastrowid
        else:
            playlist_id = pl["id"]

        cursor.execute("INSERT OR IGNORE INTO songs (file_path, title, artist, album, duration, artwork_path) VALUES (?, ?, ?, ?, ?, ?)",
                       (file_path, title, artist, album, duration, artwork_path))
        cursor.execute("SELECT id FROM songs WHERE file_path = ?", (file_path,))
        song_id = cursor.fetchone()["id"]

        cursor.execute("SELECT MAX(position) as max_pos FROM playlist_items WHERE playlist_id = ?", (playlist_id,))
        row = cursor.fetchone()
        next_pos = (row["max_pos"] or 0) + 1

        cursor.execute("INSERT INTO playlist_items (playlist_id, song_id, position) VALUES (?, ?, ?)",
                       (playlist_id, song_id, next_pos))
        conn.commit()
        conn.close()
