import sys
import os
from PySide6.QtWidgets import QApplication, QMainWindow
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtCore import QUrl

from app.database import init_db
from app.music_engine import MusicEngine
from app.playlist_manager import PlaylistManager
from app.shortcut_manager import ShortcutManager
from app.communication import Bridge

class MainWindow(QMainWindow):
    def __init__(self, music_engine):
        super().__init__()
        self.music_engine = music_engine
        self.setWindowTitle("3D Desktop Music Experience")
        self.resize(1200, 800)

        self.web_view = QWebEngineView(self)
        self.setCentralWidget(self.web_view)

        self.channel = QWebChannel()
        self.bridge = Bridge(music_engine)
        self.channel.registerObject("bridge", self.bridge)
        self.web_view.page().setWebChannel(self.channel)

        html_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "visual", "index.html"))
        self.web_view.setUrl(QUrl.fromLocalFile(html_path))

    def closeEvent(self, event):
        event.ignore()
        self.hide()

class MusicAgent:
    def __init__(self):
        init_db()
        self.app = QApplication(sys.argv)
        self.music_engine = MusicEngine()
        
        songs = PlaylistManager.get_default_playlist_songs()
        if songs:
            self.music_engine.load_playlist(songs)

        self.window = MainWindow(self.music_engine)
        
        self.shortcut_manager = ShortcutManager()
        self.shortcut_manager.triggered.connect(self.handle_shortcut)
        self.shortcut_manager.start()

    def handle_shortcut(self, action):
        if action == "activate":
            if self.music_engine.player.playbackState() != self.music_engine.player.PlaybackState.PlayingState:
                self.music_engine.play()
            self.window.show()
            self.window.raise_()
            self.window.activateWindow()
        elif action == "play_pause":
            self.music_engine.pause_resume()
        elif action == "next":
            self.music_engine.next_song()
        elif action == "previous":
            self.music_engine.previous_song()
        elif action == "hide":
            self.window.hide()
        elif action == "exit":
            self.shortcut_manager.stop()
            self.app.quit()

    def run(self):
        sys.exit(self.app.exec())

if __name__ == "__main__":
    agent = MusicAgent()
    agent.run()
