import * as THREE from 'three';

export function createPosterScene(container) {
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0b0e);

    const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 7;

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.5);
    dirLight.position.set(5, 5, 5);
    dirLight.castShadow = true;
    scene.add(dirLight);

    const geometry = new THREE.BoxGeometry(3, 4.5, 0.15);
    const material = new THREE.MeshStandardMaterial({
        color: 0x1e1e24,
        roughness: 0.3,
        metalness: 0.2
    });

    const posterCard = new THREE.Mesh(geometry, material);
    posterCard.castShadow = true;
    posterCard.receiveShadow = true;
    scene.add(posterCard);

    let mouseX = 0, mouseY = 0;
    window.addEventListener('mousemove', (event) => {
        mouseX = (event.clientX / window.innerWidth) * 2 - 1;
        mouseY = -(event.clientY / window.innerHeight) * 2 + 1;
    });

    let clock = new THREE.Clock();

    function animate() {
        requestAnimationFrame(animate);
        let elapsedTime = clock.getElapsedTime();

        posterCard.position.y = Math.sin(elapsedTime * 1.5) * 0.15;
        posterCard.rotation.y = THREE.MathUtils.lerp(posterCard.rotation.y, mouseX * 0.4 + Math.sin(elapsedTime * 0.5) * 0.05, 0.05);
        posterCard.rotation.x = THREE.MathUtils.lerp(posterCard.rotation.x, mouseY * 0.4, 0.05);

        renderer.render(scene, camera);
    }

    animate();

    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
}
