import { createPosterScene } from './poster.js';

document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('canvas-container');
    createPosterScene(container);

    if (typeof QWebChannel !== 'undefined') {
        new QWebChannel(qt.webChannelTransport, (channel) => {
            window.bridge = channel.objects.bridge;

            document.getElementById('play-btn').addEventListener('click', () => {
                if (window.bridge) window.bridge.handleCommand('pause');
            });
            document.getElementById('next-btn').addEventListener('click', () => {
                if (window.bridge) window.bridge.handleCommand('next');
            });
            document.getElementById('prev-btn').addEventListener('click', () => {
                if (window.bridge) window.bridge.handleCommand('previous');
            });
        });
    }
});
