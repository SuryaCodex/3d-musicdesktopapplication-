# 3D Desktop Music Experience

A lightweight Windows background music agent with a stunning 3D animated desktop poster interface, global keyboard shortcut integration, and offline-first local playback.

## Features
- **Global Shortcut Activation (`Ctrl + Alt + R`)**: Automatically starts your predefined playlist in order and launches the 3D animated poster interface.
- **3D Floating Poster Experience**: Immersive Three.js/WebGL floating 3D card with realistic perspective, shadows, lighting, and mouse tilt.
- **Background Operation**: Music engine and background agent run independently of the visual interface. Closing the visual window never stops the music.
- **Complete Offline Support**: 100% local music and artwork playback with zero internet dependency.
- **Audio-Reactive Visualizer**: Real-time spectrum analysis reacting to audio playback.

## Technology Stack
- **Backend**: Python 3.12, PySide6, Qt Multimedia, SQLite, Mutagen
- **Frontend**: HTML5, CSS3, JavaScript, Three.js, WebGL, Vite
- **Packaging**: PyInstaller, Windows Task Scheduler
