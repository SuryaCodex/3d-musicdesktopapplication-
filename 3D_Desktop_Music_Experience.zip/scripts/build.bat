@echo off
call venv\Scripts\activate
pip install pyinstaller
pyinstaller --noconsole --onedir --name "3DDesktopMusicExperience" --add-data "visual;visual" --add-data "assets;assets" app/main.py
echo Build complete. Executable available in dist/3DDesktopMusicExperience/
pause
